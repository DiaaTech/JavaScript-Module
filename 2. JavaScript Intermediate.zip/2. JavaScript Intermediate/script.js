// JavaScript Intermediate

// for (let start = 0; start < 10; start = start + 1) {
//   console.log(start, 'Talha')
// }

// Loop for prinint numbers till 30 only even number
// for (let start = 2; start <= 30; start = start + 2) {
//   console.log(start)
// }

// Loop | Print Table of 2
for (let i = 1; i <= 10; i++) {
  console.log('2 * ', i, '= ', i * 2)
}
